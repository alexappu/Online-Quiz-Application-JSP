-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 29, 2022 at 10:56 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `onlinequiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `ans_id` int(11) NOT NULL auto_increment,
  `answer` varchar(150) default NULL,
  `answer1` varchar(150) default NULL,
  `answer2` varchar(150) default NULL,
  `answer3` varchar(150) default NULL,
  `q_id` int(11) NOT NULL,
  PRIMARY KEY  (`ans_id`),
  KEY `q_id` (`q_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`ans_id`, `answer`, `answer1`, `answer2`, `answer3`, `q_id`) VALUES
(1, '           a ', '           b ', '          c  ', '            d', 1),
(2, '            Security is a state of freedom', '            Security is nothing', '            ', '            ', 3),
(3, '            servlet is server', '                 servlet is client', '                 servlet is cookie', '                 servlet is session', 5),
(4, '            jjkd', '            fjjj', '            djjdd', '            djjdjs', 6),
(5, '            hjd', '            jdsjds', '            ', '            ', 7),
(7, '            Cndkod', '            ddf', '            fddff', '            ffffdfd', 8),
(8, '            Python is an ordinary language', '            Python is a programming language', '            ', '            ', 9),
(9, '            database management system', '            data management system', '            data base object', '            data base subject', 10),
(10, '            tuple is in python', '              tuple is in java', '              tuple is in OOPS', '              tuple is in C', 11),
(11, '            django is a framework', '            django is a structure', '            django is a object', '            ', 12),
(12, '            Flask is a framework', '            Flask is object', '            ', '            ', 14),
(13, '            dynamic is study of machine temperature', '              dynamic is study of machine ', '              dynamic is study of temperature', '            ', 15),
(14, '            it is an art of electricity', '            not a art', '            ', '            ', 16),
(17, '            jkdkjasjk', '            jkadjkda', '            hjjkd', '            jdja', 20),
(18, '       gfghg     ', '   gvgggg         ', '         gfgfffg   ', '          tghhghghg  ', 22),
(20, '            Big data is a collection of big data', '            Big data is a collection of small data', '     Big data is a collection of little data', '         Big data is a collection of long data', 26),
(21, '            jdsjkas', '            mnsan', '            njshsx', '            jjcjxz', 27),
(22, '            cnjjdsd', '            kskd', '            snnds', '            nsmsx', 28),
(23, '            jsj', '            sjsd', '            dsjhjdssj', '            dssd', 29);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dep_id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `status` varchar(15) NOT NULL,
  PRIMARY KEY  (`dep_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dep_id`, `name`, `status`) VALUES
(1, 'MCA', 'Added'),
(9, 'MBA', 'Added'),
(10, 'btech', 'Removed'),
(12, 'B-Tech CS', 'Removed'),
(14, 'Btech-EEE', 'Added'),
(15, 'Btech - Mech', 'Added'),
(17, 'Btech-CS', 'Added'),
(18, 'Btech-civil1', 'Removed'),
(19, 'cs1', 'Removed'),
(20, 'Mtech Civil', 'Added');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `q_id` int(11) NOT NULL auto_increment,
  `que_name` varchar(150) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `q_status` varchar(50) NOT NULL,
  PRIMARY KEY  (`q_id`),
  KEY `sub_id` (`sub_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`q_id`, `que_name`, `sub_id`, `q_status`) VALUES
(1, 'What is jsp', 2, 'Answer Added'),
(2, 'abcd\r\n', 1, 'Answer Added'),
(3, 'What is security ?', 8, 'Answer Added'),
(4, 'what is ds', 1, 'Answer Added'),
(5, 'what is servlet', 2, 'Answer Added'),
(6, 'what is linear probing', 1, 'Answer Added'),
(7, 'what is hashing', 1, 'Answer Added'),
(8, 'What is Computer Network?', 3, 'Answer Added'),
(9, 'what is python', 5, 'Answer Added'),
(10, 'what is dbms', 1, 'Answer Added'),
(11, 'What is tuple', 5, 'Answer Added'),
(12, 'what is django', 5, 'Answer Added'),
(13, 'what is data', 5, 'Answer Added'),
(14, 'what is flask', 5, 'Answer Added'),
(15, 'what is dynamics', 10, 'Answer Added'),
(16, 'what is electronis', 7, 'Answer Added'),
(17, 'what is oops', 11, 'Answer Added'),
(20, 'what is osi model', 3, 'Answer Added'),
(21, 'abcde', 3, 'Answer Added'),
(22, 'whatsoodhd', 3, 'Answer Added'),
(26, 'what is big data', 9, 'Answer Added'),
(27, 'what is ipv4', 3, 'Answer Added'),
(28, 'what is class', 5, 'Answer Added'),
(29, 'what is class', 2, 'Answer Added');

-- --------------------------------------------------------

--
-- Table structure for table `score`
--

CREATE TABLE `score` (
  `s_id` int(11) NOT NULL auto_increment,
  `score` int(100) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY  (`s_id`),
  KEY `sub_id` (`sub_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `score`
--

INSERT INTO `score` (`s_id`, `score`, `sub_id`, `user_id`) VALUES
(1, 4, 1, 3),
(2, 5, 1, 3),
(3, 5, 8, 3),
(4, 5, 7, 6),
(5, 5, 2, 3),
(6, 5, 7, 6),
(7, 5, 7, 6),
(8, 5, 2, 3),
(9, 0, 3, 3),
(10, 3, 1, 3),
(12, 0, 1, 3),
(13, 0, 1, 3),
(14, 0, 1, 3),
(15, 0, 1, 3),
(16, 0, 1, 3),
(17, 0, 1, 3),
(18, 3, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `sub_id` int(11) NOT NULL auto_increment,
  `sub_name` varchar(50) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `status` int(50) NOT NULL,
  PRIMARY KEY  (`sub_id`),
  KEY `dep_id` (`dep_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`sub_id`, `sub_name`, `dep_id`, `status`) VALUES
(1, 'Advanced Data Structures', 1, 1),
(2, 'Advanced Java', 1, 1),
(3, 'Advance Computer Networks', 1, 1),
(5, 'Python Programming', 1, 1),
(6, 'Python Programming', 17, 1),
(7, 'Electronics Basics', 14, 1),
(8, 'Cyber Security', 1, 1),
(9, 'big data', 1, 1),
(10, 'dynamics', 15, 1),
(11, 'c++', 19, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL auto_increment,
  `name` varchar(150) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `email` varchar(150) NOT NULL,
  `type_id` int(11) NOT NULL,
  `password` varchar(150) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY  (`user_id`),
  KEY `dep_id` (`dep_id`),
  KEY `type_id` (`type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `name`, `dep_id`, `email`, `type_id`, `password`, `status`) VALUES
(1, 'Alex James', 1, 'alex@gmail.com', 1, 'alex123', '1'),
(2, 'Alisha ', 1, 'alisha@gmail.com', 2, 'alisha123', '1'),
(3, 'Amal C Bino', 1, 'amal@gmail.com', 3, 'amal123', '1'),
(4, 'Ammu', 15, 'ammu@gmail.com', 3, 'ammu123', '0'),
(5, 'Ganesh', 1, 'ganesh@gmail.com', 3, 'ganesh123', '0'),
(6, 'Anjana Santhosh', 14, 'anjana@gmail.com', 3, 'anjana123', '1'),
(8, 'Anet Jose', 14, 'anet@gmail.com', 2, 'anet123', '1'),
(9, 'Alan P Nath', 1, 'alan@gmail.com', 2, 'alan123', '0'),
(10, 'Adithyan', 17, 'ad@gmail.com', 2, 'ad123', '1'),
(11, 'Binimol Joseph', 1, 'binimol@gmail.com', 3, 'bini123', '1'),
(12, 'fatima', 15, 'fatima@gmail.com', 2, 'fatima123', '1'),
(13, 'martin', 15, 'martin@gmail.com', 3, 'martin123', '1'),
(14, 'arun', 19, 'arun@gmail.com', 2, 'arun123', '1'),
(15, 'Preetha S', 1, 'preetha@gmail.com', 2, 'preetha123', '0'),
(16, 'Ligin Thomas', 14, 'ck@gmail.com', 2, 'ck123', '0');

-- --------------------------------------------------------

--
-- Table structure for table `user_type`
--

CREATE TABLE `user_type` (
  `type_id` int(11) NOT NULL auto_increment,
  `type_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_type`
--

INSERT INTO `user_type` (`type_id`, `type_name`) VALUES
(1, 'Admin'),
(2, 'Teacher'),
(3, 'Student');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answer`
--
ALTER TABLE `answer`
  ADD CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`q_id`) REFERENCES `question` (`q_id`);

--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `question_ibfk_1` FOREIGN KEY (`sub_id`) REFERENCES `subject` (`sub_id`);

--
-- Constraints for table `score`
--
ALTER TABLE `score`
  ADD CONSTRAINT `score_ibfk_1` FOREIGN KEY (`sub_id`) REFERENCES `subject` (`sub_id`),
  ADD CONSTRAINT `score_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `subject`
--
ALTER TABLE `subject`
  ADD CONSTRAINT `subject_ibfk_1` FOREIGN KEY (`dep_id`) REFERENCES `department` (`dep_id`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`dep_id`) REFERENCES `department` (`dep_id`),
  ADD CONSTRAINT `user_ibfk_2` FOREIGN KEY (`type_id`) REFERENCES `user_type` (`type_id`);
